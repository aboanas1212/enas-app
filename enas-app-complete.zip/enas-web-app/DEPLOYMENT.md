# دليل النشر والبناء

## 🚀 بناء APK النهائي

### الخطوة 1: تجهيز البيئة
```bash
# تأكد من تثبيت Java و Android SDK
java -version
echo $ANDROID_HOME
```

### الخطوة 2: بناء الويب
```bash
npm run build
```

### الخطوة 3: مزامنة Capacitor
```bash
npx cap sync android
```

### الخطوة 4: فتح Android Studio
```bash
npx cap open android
```

### الخطوة 5: بناء APK
في Android Studio:
1. اختر `Build` من القائمة
2. اختر `Build Bundle(s) / APK(s)`
3. اختر `Build APK(s)`
4. انتظر انتهاء البناء

### الخطوة 6: موقع APK
```
android/app/build/outputs/apk/debug/app-debug.apk
```

## 📦 بناء Release APK

### الخطوة 1: إنشاء مفتاح التوقيع
```bash
keytool -genkey -v -keystore enas.keystore -keyalg RSA -keysize 2048 -validity 10000 -alias enas
```

### الخطوة 2: تحديث gradle.properties
```
MYAPP_RELEASE_STORE_FILE=enas.keystore
MYAPP_RELEASE_KEY_ALIAS=enas
MYAPP_RELEASE_STORE_PASSWORD=<password>
MYAPP_RELEASE_KEY_PASSWORD=<password>
```

### الخطوة 3: بناء Release APK
```bash
cd android
./gradlew assembleRelease
```

## ✅ الاختبار

### اختبار الويب
```bash
npm run dev
```

### اختبار على الهاتف
```bash
npx cap run android
```

### اختبار بدون إنترنت
1. فعّل وضع الطيران
2. جرّب التطبيق
3. تأكد من عمل جميع الألعاب

## 📊 الحجم والأداء

- حجم الويب: ~472 KB
- حجم APK (debug): ~50-60 MB
- حجم APK (release): ~30-40 MB
- الأداء: سلس على جميع الأجهزة

## 🔒 الأمان

- جميع البيانات محلية
- لا توجد طلبات خارجية
- لا توجد تتبعات أو إعلانات
- آمن تماماً للأطفال

## 📱 التوافقية

- Android 5.0+ (API 21+)
- iOS (عبر Capacitor)
- الويب (جميع المتصفحات الحديثة)

## 🐛 استكشاف الأخطاء

### المشكلة: APK لا يعمل بدون إنترنت
**الحل**: تأكد من تفعيل Service Worker في index.html

### المشكلة: الأصوات لا تعمل
**الحل**: تحقق من أن ملفات الأصوات موجودة في `public/assets/sounds/`

### المشكلة: البيانات لا تُحفظ
**الحل**: تأكد من أن localStorage مفعّل في الإعدادات

## 📝 ملاحظات مهمة

- تأكد من تحديث رقم الإصدار في `package.json` قبل كل بناء
- احتفظ بنسخة احتياطية من مفتاح التوقيع
- اختبر التطبيق على أجهزة مختلفة قبل النشر
- راقب حجم APK وحاول تقليله إن أمكن

---

**تم الإنشاء بنجاح! 🎉**
