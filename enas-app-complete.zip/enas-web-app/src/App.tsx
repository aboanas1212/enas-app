import { useState, useEffect } from 'react';
import { initializeAudioSystem, playEffect } from './logic/audioManager';
import { HomeScreen } from './screens/HomeScreen';
import { LearnScreen } from './screens/LearnScreen';
import { QuizScreen } from './screens/QuizScreen';
import { MatchingGame } from './screens/MatchingGame';
import { SpeedGame } from './screens/SpeedGame';
import { OrderingGame } from './screens/OrderingGame';
import { CatchGame } from './screens/CatchGame';
import { MemoryGame } from './screens/MemoryGame';
import { PaintGame } from './screens/PaintGame';
import { StatsScreen } from './screens/StatsScreen';
import { DailyChallengeScreen } from './screens/DailyChallengeScreen';

type GameMode = 'learn' | 'quiz' | 'matching' | 'speed' | 'ordering' | 'catch' | 'memory' | 'paint';
type Screen = GameMode | 'home' | 'stats' | 'daily';

function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>('home');

  useEffect(() => {
    initializeAudioSystem();
  }, []);

  const handleSelectMode = (mode: string) => {
    playEffect('click');
    setCurrentScreen(mode as Screen);
  };

  const handleBack = () => {
    playEffect('click');
    setCurrentScreen('home');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {currentScreen === 'home' && <HomeScreen onSelectMode={handleSelectMode} />}
      {currentScreen === 'learn' && <LearnScreen onBack={handleBack} />}
      {currentScreen === 'quiz' && <QuizScreen onBack={handleBack} />}
      {currentScreen === 'matching' && <MatchingGame onBack={handleBack} />}
      {currentScreen === 'speed' && <SpeedGame onBack={handleBack} />}
      {currentScreen === 'ordering' && <OrderingGame onBack={handleBack} />}
      {currentScreen === 'catch' && <CatchGame onBack={handleBack} />}
      {currentScreen === 'memory' && <MemoryGame onBack={handleBack} />}
      {currentScreen === 'paint' && <PaintGame onBack={handleBack} />}
      {currentScreen === 'stats' && <StatsScreen onBack={handleBack} />}
      {currentScreen === 'daily' && <DailyChallengeScreen onBack={handleBack} />}
    </div>
  );
}

export default App;
