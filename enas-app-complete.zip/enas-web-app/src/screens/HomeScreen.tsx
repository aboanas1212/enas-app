import React from 'react';
import { getUserStats } from '../data/userProgress';

interface HomeScreenProps {
  onSelectMode: (mode: string) => void;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({ onSelectMode }) => {
  const stats = getUserStats();

  const gameCards = [
    { id: 'learn', title: '📖 تعلم', desc: 'تعلم الجدول', color: 'from-blue-400 to-blue-600' },
    { id: 'quiz', title: '✏️ اختبار', desc: '10 أسئلة', color: 'from-purple-400 to-purple-600' },
    { id: 'matching', title: '🎯 مطابقة', desc: 'طابق الإجابات', color: 'from-pink-400 to-pink-600' },
    { id: 'speed', title: '⚡ سرعة', desc: '30 ثانية', color: 'from-red-400 to-red-600' },
    { id: 'ordering', title: '📊 ترتيب', desc: 'رتب الإجابات', color: 'from-green-400 to-green-600' },
    { id: 'catch', title: '🎮 صيد', desc: 'اصطد الإجابات', color: 'from-yellow-400 to-yellow-600' },
    { id: 'memory', title: '🧠 ذاكرة', desc: 'بطاقات مخفية', color: 'from-indigo-400 to-indigo-600' },
    { id: 'paint', title: '🎨 تلوين', desc: 'لون الإجابة', color: 'from-orange-400 to-orange-600' },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="text-center mb-8 pt-6">
        <h1 className="text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-purple-600 mb-2">
          🎓 إيناس
        </h1>
        <p className="text-xl text-gray-700">عالم جداول الضرب المبهج</p>
      </div>

      {stats.totalGames > 0 && (
        <div className="grid grid-cols-3 gap-4 mb-8 max-w-md mx-auto">
          <div className="bg-white rounded-lg shadow-lg p-4 text-center">
            <div className="text-2xl font-bold text-blue-600">{stats.totalCorrect}</div>
            <div className="text-sm text-gray-600">صحيح</div>
          </div>
          <div className="bg-white rounded-lg shadow-lg p-4 text-center">
            <div className="text-2xl font-bold text-green-600">{Math.round(stats.averageAccuracy)}%</div>
            <div className="text-sm text-gray-600">نسبة</div>
          </div>
          <div className="bg-white rounded-lg shadow-lg p-4 text-center">
            <div className="text-2xl font-bold text-purple-600">{stats.totalGames}</div>
            <div className="text-sm text-gray-600">ألعاب</div>
          </div>
        </div>
      )}

      <div className="grid grid-cols-2 gap-3 max-w-2xl mx-auto mb-8">
        {gameCards.map((card) => (
          <button
            key={card.id}
            onClick={() => onSelectMode(card.id)}
            className={`bg-gradient-to-br ${card.color} rounded-xl p-4 text-white shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-200`}
          >
            <div className="text-2xl mb-1">{card.title.split(' ')[0]}</div>
            <h2 className="text-sm font-bold">{card.title.split(' ').slice(1).join(' ')}</h2>
            <p className="text-xs opacity-90">{card.desc}</p>
          </button>
        ))}
      </div>

      <div className="flex justify-center gap-4 max-w-md mx-auto">
        <button
          onClick={() => onSelectMode('stats')}
          className="flex-1 bg-white text-gray-800 font-bold py-3 px-4 rounded-lg shadow-lg hover:shadow-xl transform hover:scale-105 transition-all"
        >
          📊 إحصائياتي
        </button>
        <button
          onClick={() => onSelectMode('daily')}
          className="flex-1 bg-gradient-to-r from-orange-400 to-red-500 text-white font-bold py-3 px-4 rounded-lg shadow-lg hover:shadow-xl transform hover:scale-105 transition-all"
        >
          🎁 تحدي يومي
        </button>
      </div>
    </div>
  );
};
