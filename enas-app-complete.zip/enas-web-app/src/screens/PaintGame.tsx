import React, { useState } from 'react';
import { getRandomProblems } from '../data/multiplicationTables';
import { updateStatsAfterGame } from '../data/userProgress';
import { playFeedback } from '../logic/audioManager';

interface PaintGameProps {
  onBack: () => void;
}

export const PaintGame: React.FC<PaintGameProps> = ({ onBack }) => {
  const [problems] = useState(getRandomProblems(10));
  const [index, setIndex] = useState(0);
  const [correct, setCorrect] = useState(0);
  const [finished, setFinished] = useState(false);
  const [selected, setSelected] = useState<number | null>(null);

  const current = problems[index];
  const options = [current.result, current.result + 3, current.result - 3, current.result + 7].filter(n => n > 0);

  const handleSelect = async (ans: number) => {
    setSelected(ans);
    if (ans === current.result) {
      setCorrect(correct + 1);
      await playFeedback('correct');
      setTimeout(() => {
        if (index === problems.length - 1) {
          updateStatsAfterGame({
            id: Date.now().toString(),
            gameType: 'paint',
            table: 5,
            difficulty: 'easy',
            correct,
            incorrect: problems.length - correct - 1,
            totalTime: 0,
            date: new Date().toISOString(),
            percentage: Math.round(((correct + 1) / problems.length) * 100),
          });
          setFinished(true);
        } else {
          setIndex(index + 1);
          setSelected(null);
        }
      }, 300);
    } else {
      await playFeedback('wrong');
      setTimeout(() => setSelected(null), 300);
    }
  };

  if (finished) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-orange-50 to-pink-100 p-4 flex items-center justify-center">
        <div className="max-w-md w-full bg-white rounded-2xl shadow-2xl p-8 text-center">
          <div className="text-6xl mb-4">🎨</div>
          <h2 className="text-3xl font-bold text-gray-800 mb-4">جميل جداً!</h2>
          <div className="text-5xl font-bold text-orange-600 mb-6">{correct}/{problems.length}</div>
          <button onClick={onBack} className="w-full bg-orange-500 text-white py-3 rounded-lg">العودة</button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-pink-100 p-4">
      <div className="max-w-md mx-auto">
        <h1 className="text-3xl font-bold text-orange-600 mb-6 text-center">🎨 لعبة التلوين</h1>

        <div className="bg-white rounded-2xl shadow-lg p-8 text-center mb-6">
          <p className="text-gray-600 mb-4">اختر الإجابة الصحيحة</p>
          <div className="text-5xl font-bold text-orange-600">{current.a} × {current.b}</div>
        </div>

        <div className="grid grid-cols-2 gap-4 mb-6">
          {options.map((ans, idx) => (
            <button
              key={idx}
              onClick={() => handleSelect(ans)}
              className={`py-6 px-4 rounded-xl font-bold text-2xl transition-all ${
                selected === ans
                  ? ans === current.result
                    ? 'bg-green-500 text-white scale-110'
                    : 'bg-red-500 text-white scale-95'
                  : 'bg-gradient-to-br from-pink-400 to-orange-400 text-white shadow-lg hover:shadow-xl'
              }`}
            >
              {ans}
            </button>
          ))}
        </div>

        <div className="text-center text-gray-600">
          {index + 1}/10 | ✓ {correct}
        </div>
      </div>
    </div>
  );
};
