import React, { useState, useEffect } from 'react';
import { getRandomProblems, getWrongAnswers, shuffleArray } from '../data/multiplicationTables';
import { updateStatsAfterGame } from '../data/userProgress';
import { playFeedback } from '../logic/audioManager';

interface QuizScreenProps {
  onBack: () => void;
}

export const QuizScreen: React.FC<QuizScreenProps> = ({ onBack }) => {
  const [problems] = useState(getRandomProblems(10));
  const [index, setIndex] = useState(0);
  const [correct, setCorrect] = useState(0);
  const [selected, setSelected] = useState<number | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [answers, setAnswers] = useState<number[]>([]);
  const [finished, setFinished] = useState(false);

  const current = problems[index];

  useEffect(() => {
    const wrong = getWrongAnswers(current.result, 3);
    const all = shuffleArray([current.result, ...wrong]);
    setAnswers(all);
  }, [current]);

  const handleAnswer = async (ans: number) => {
    setSelected(ans);
    setShowResult(true);
    if (ans === current.result) {
      setCorrect(correct + 1);
      await playFeedback('correct');
    } else {
      await playFeedback('wrong');
    }
  };

  const handleNext = () => {
    if (index === problems.length - 1) {
      const pct = Math.round((correct / problems.length) * 100);
      updateStatsAfterGame({
        id: Date.now().toString(),
        gameType: 'quiz',
        table: 5,
        difficulty: 'medium',
        correct,
        incorrect: problems.length - correct,
        totalTime: 0,
        date: new Date().toISOString(),
        percentage: pct,
      });
      setFinished(true);
    } else {
      setIndex(index + 1);
      setSelected(null);
      setShowResult(false);
    }
  };

  if (finished) {
    const pct = Math.round((correct / problems.length) * 100);
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 to-indigo-100 p-4 flex items-center justify-center">
        <div className="max-w-md w-full bg-white rounded-2xl shadow-2xl p-8 text-center">
          <div className="text-6xl mb-4">{pct === 100 ? '🌟' : pct >= 80 ? '👏' : '💪'}</div>
          <h2 className="text-3xl font-bold text-gray-800 mb-4">انتهى!</h2>
          <div className="text-5xl font-bold text-purple-600 mb-6">{pct}%</div>
          <div className="grid grid-cols-2 gap-4 mb-6">
            <div className="bg-green-50 p-4 rounded-lg">
              <div className="text-3xl font-bold text-green-600">{correct}</div>
              <p className="text-sm text-gray-600">صحيح</p>
            </div>
            <div className="bg-red-50 p-4 rounded-lg">
              <div className="text-3xl font-bold text-red-600">{problems.length - correct}</div>
              <p className="text-sm text-gray-600">خطأ</p>
            </div>
          </div>
          <button onClick={onBack} className="w-full bg-purple-500 text-white py-3 rounded-lg">العودة</button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-indigo-100 p-4">
      <div className="max-w-md mx-auto">
        <h1 className="text-3xl font-bold text-purple-600 mb-4 text-center">✏️ اختبر نفسك</h1>
        <p className="text-center text-gray-600 mb-6">{index + 1}/10 | ✓ {correct}</p>

        <div className="bg-white rounded-2xl shadow-lg p-8 text-center mb-6">
          <p className="text-gray-600 mb-4">ما الإجابة الصحيحة؟</p>
          <div className="text-5xl font-bold text-purple-600">{current.a} × {current.b}</div>
        </div>

        <div className="grid grid-cols-2 gap-3 mb-6">
          {answers.map((ans) => (
            <button
              key={ans}
              onClick={() => handleAnswer(ans)}
              disabled={showResult}
              className={`py-4 px-3 rounded-lg font-bold text-lg ${
                showResult
                  ? ans === current.result
                    ? 'bg-green-500 text-white'
                    : selected === ans
                    ? 'bg-red-500 text-white'
                    : 'bg-gray-200'
                  : selected === ans
                  ? 'bg-purple-600 text-white'
                  : 'bg-white shadow hover:shadow-lg'
              }`}
            >
              {ans}
            </button>
          ))}
        </div>

        {showResult && (
          <button onClick={handleNext} className="w-full bg-blue-500 text-white py-3 rounded-lg font-bold">
            {index === problems.length - 1 ? 'انتهى ✓' : 'التالي →'}
          </button>
        )}
      </div>
    </div>
  );
};
