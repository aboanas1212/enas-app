import React, { useState, useEffect } from 'react';
import { getRandomProblems, getWrongAnswers, shuffleArray } from '../data/multiplicationTables';
import { updateStatsAfterGame } from '../data/userProgress';
import { playFeedback } from '../logic/audioManager';

interface DailyChallengeScreenProps {
  onBack: () => void;
}

export const DailyChallengeScreen: React.FC<DailyChallengeScreenProps> = ({ onBack }) => {
  const [problems] = useState(getRandomProblems(5));
  const [index, setIndex] = useState(0);
  const [correct, setCorrect] = useState(0);
  const [selected, setSelected] = useState<number | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [answers, setAnswers] = useState<number[]>([]);
  const [finished, setFinished] = useState(false);

  const current = problems[index];

  useEffect(() => {
    if (current) {
      const wrong = getWrongAnswers(current.result, 3);
      const all = shuffleArray([current.result, ...wrong]);
      setAnswers(all);
    }
  }, [current]);

  const handleAnswer = async (ans: number) => {
    setSelected(ans);
    setShowResult(true);
    if (ans === current.result) {
      setCorrect(correct + 1);
      await playFeedback('correct');
    } else {
      await playFeedback('wrong');
    }
  };

  const handleNext = () => {
    if (index === problems.length - 1) {
      const pct = Math.round((correct / problems.length) * 100);
      updateStatsAfterGame({
        id: Date.now().toString(),
        gameType: 'daily',
        table: 5,
        difficulty: 'medium',
        correct,
        incorrect: problems.length - correct,
        totalTime: 0,
        date: new Date().toISOString(),
        percentage: pct,
      });
      setFinished(true);
    } else {
      setIndex(index + 1);
      setSelected(null);
      setShowResult(false);
    }
  };

  if (finished) {
    const pct = Math.round((correct / problems.length) * 100);
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-100 p-4 flex items-center justify-center">
        <div className="max-w-md w-full bg-white rounded-2xl shadow-2xl p-8 text-center">
          <div className="text-6xl mb-4">{pct === 100 ? '🎁' : '🌟'}</div>
          <h2 className="text-3xl font-bold text-gray-800 mb-4">التحدي اليومي</h2>
          <div className="text-5xl font-bold text-purple-600 mb-6">{pct}%</div>
          <p className="text-gray-600 mb-6">عد غداً للتحدي الجديد!</p>
          <button onClick={onBack} className="w-full bg-purple-500 text-white py-3 rounded-lg">العودة</button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-100 p-4">
      <div className="max-w-md mx-auto">
        <h1 className="text-3xl font-bold text-purple-600 mb-4 text-center">🎁 التحدي اليومي</h1>
        <p className="text-center text-gray-600 mb-6">{index + 1}/5 | ✓ {correct}</p>

        <div className="bg-white rounded-2xl shadow-lg p-8 text-center mb-6">
          <p className="text-gray-600 mb-4">ما الإجابة الصحيحة؟</p>
          <div className="text-5xl font-bold text-purple-600">{current.a} × {current.b}</div>
        </div>

        <div className="grid grid-cols-2 gap-3 mb-6">
          {answers.map((ans) => (
            <button
              key={ans}
              onClick={() => handleAnswer(ans)}
              disabled={showResult}
              className={`py-4 px-3 rounded-lg font-bold text-lg ${
                showResult
                  ? ans === current.result
                    ? 'bg-green-500 text-white'
                    : selected === ans
                    ? 'bg-red-500 text-white'
                    : 'bg-gray-200'
                  : selected === ans
                  ? 'bg-purple-600 text-white'
                  : 'bg-white shadow hover:shadow-lg'
              }`}
            >
              {ans}
            </button>
          ))}
        </div>

        {showResult && (
          <button onClick={handleNext} className="w-full bg-blue-500 text-white py-3 rounded-lg font-bold">
            {index === problems.length - 1 ? 'انتهى ✓' : 'التالي →'}
          </button>
        )}
      </div>
    </div>
  );
};
