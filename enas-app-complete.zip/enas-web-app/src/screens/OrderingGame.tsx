import React, { useState } from 'react';
import { getRandomProblems, shuffleArray } from '../data/multiplicationTables';
import { updateStatsAfterGame } from '../data/userProgress';
import { playFeedback } from '../logic/audioManager';

interface OrderingGameProps {
  onBack: () => void;
}

export const OrderingGame: React.FC<OrderingGameProps> = ({ onBack }) => {
  const [problems] = useState(getRandomProblems(10));
  const [index, setIndex] = useState(0);
  const [correct, setCorrect] = useState(0);
  const [finished, setFinished] = useState(false);
  const [selected, setSelected] = useState<number | null>(null);

  const current = problems[index];
  const answers = [current.result, current.result + 5, current.result - 5, current.result + 10].filter(n => n > 0);
  const shuffled = shuffleArray(answers);

  const handleSelect = async (ans: number) => {
    setSelected(ans);
    if (ans === current.result) {
      setCorrect(correct + 1);
      await playFeedback('correct');
      setTimeout(() => {
        if (index === problems.length - 1) {
          updateStatsAfterGame({
            id: Date.now().toString(),
            gameType: 'ordering',
            table: 5,
            difficulty: 'medium',
            correct,
            incorrect: problems.length - correct - 1,
            totalTime: 0,
            date: new Date().toISOString(),
            percentage: Math.round(((correct + 1) / problems.length) * 100),
          });
          setFinished(true);
        } else {
          setIndex(index + 1);
          setSelected(null);
        }
      }, 300);
    } else {
      await playFeedback('wrong');
      setTimeout(() => setSelected(null), 300);
    }
  };

  if (finished) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 to-emerald-100 p-4 flex items-center justify-center">
        <div className="max-w-md w-full bg-white rounded-2xl shadow-2xl p-8 text-center">
          <div className="text-6xl mb-4">🏆</div>
          <h2 className="text-3xl font-bold text-gray-800 mb-4">ممتاز!</h2>
          <div className="text-5xl font-bold text-green-600 mb-6">{correct}/{problems.length}</div>
          <button onClick={onBack} className="w-full bg-green-500 text-white py-3 rounded-lg">العودة</button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-emerald-100 p-4">
      <div className="max-w-md mx-auto">
        <h1 className="text-3xl font-bold text-green-600 mb-6 text-center">📊 ترتيب الإجابات</h1>

        <div className="bg-white rounded-2xl shadow-lg p-8 text-center mb-6">
          <p className="text-gray-600 mb-4">رتب الإجابات من الأصغر للأكبر</p>
          <div className="text-5xl font-bold text-green-600">{current.a} × {current.b}</div>
        </div>

        <div className="space-y-3 mb-6">
          {shuffled.map((ans, idx) => (
            <button
              key={idx}
              onClick={() => handleSelect(ans)}
              className={`w-full py-4 px-4 rounded-lg font-bold text-lg transition-all ${
                selected === ans
                  ? ans === current.result
                    ? 'bg-green-500 text-white'
                    : 'bg-red-500 text-white'
                  : 'bg-white shadow hover:shadow-lg'
              }`}
            >
              {ans}
            </button>
          ))}
        </div>

        <div className="text-center text-gray-600">
          {index + 1}/10 | ✓ {correct}
        </div>
      </div>
    </div>
  );
};
