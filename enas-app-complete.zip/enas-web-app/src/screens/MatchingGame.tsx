import React, { useState, useEffect } from 'react';
import { getRandomProblems, shuffleArray } from '../data/multiplicationTables';
import { updateStatsAfterGame } from '../data/userProgress';
import { playFeedback } from '../logic/audioManager';

interface MatchingGameProps {
  onBack: () => void;
}

export const MatchingGame: React.FC<MatchingGameProps> = ({ onBack }) => {
  const [problems] = useState(getRandomProblems(10));
  const [answers, setAnswers] = useState<number[]>([]);
  const [matches, setMatches] = useState<Set<number>>(new Set());
  const [finished, setFinished] = useState(false);

  useEffect(() => {
    const ans = shuffleArray(problems.map(p => p.result));
    setAnswers(ans);
  }, [problems]);

  const handleMatch = async (pIdx: number, aIdx: number) => {
    if (problems[pIdx].result === answers[aIdx]) {
      const newMatches = new Set(matches);
      newMatches.add(pIdx);
      setMatches(newMatches);
      await playFeedback('correct');
      
      if (newMatches.size === problems.length) {
        updateStatsAfterGame({
          id: Date.now().toString(),
          gameType: 'matching',
          table: 5,
          difficulty: 'medium',
          correct: problems.length,
          incorrect: 0,
          totalTime: 0,
          date: new Date().toISOString(),
          percentage: 100,
        });
        setFinished(true);
      }
    } else {
      await playFeedback('wrong');
    }
  };

  if (finished) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-pink-50 to-red-100 p-4 flex items-center justify-center">
        <div className="max-w-md w-full bg-white rounded-2xl shadow-2xl p-8 text-center">
          <div className="text-6xl mb-4">🌟</div>
          <h2 className="text-3xl font-bold text-gray-800 mb-4">ممتاز!</h2>
          <p className="text-lg text-gray-600 mb-6">لقد طابقت جميع الإجابات!</p>
          <button onClick={onBack} className="w-full bg-pink-500 text-white py-3 rounded-lg">العودة</button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 to-red-100 p-4">
      <div className="max-w-2xl mx-auto">
        <h1 className="text-3xl font-bold text-pink-600 mb-4 text-center">🎯 المطابقة</h1>
        <p className="text-center text-gray-600 mb-6">{matches.size}/10 مطابقات</p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <h3 className="font-bold text-gray-700 mb-3 text-center">المسائل</h3>
            <div className="space-y-2">
              {problems.map((p, idx) => (
                <div
                  key={idx}
                  className={`p-4 rounded-lg text-center font-bold cursor-pointer transition-all ${
                    matches.has(idx) ? 'bg-green-500 text-white' : 'bg-white shadow hover:shadow-lg'
                  }`}
                >
                  {p.a} × {p.b}
                </div>
              ))}
            </div>
          </div>

          <div>
            <h3 className="font-bold text-gray-700 mb-3 text-center">الإجابات</h3>
            <div className="space-y-2">
              {answers.map((ans, idx) => {
                const isUsed = Array.from(matches.values()).some(pIdx => problems[pIdx].result === ans);
                return (
                  <button
                    key={idx}
                    onClick={() => {
                      const pIdx = problems.findIndex(p => p.result === ans);
                      if (pIdx !== -1 && !matches.has(pIdx)) handleMatch(pIdx, idx);
                    }}
                    disabled={isUsed}
                    className={`w-full p-4 rounded-lg font-bold transition-all ${
                      isUsed ? 'bg-gray-300 text-gray-500 cursor-not-allowed' : 'bg-pink-500 text-white shadow hover:shadow-lg'
                    }`}
                  >
                    {ans}
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        <button onClick={onBack} className="w-full mt-6 bg-gray-500 text-white py-3 rounded-lg">العودة</button>
      </div>
    </div>
  );
};
