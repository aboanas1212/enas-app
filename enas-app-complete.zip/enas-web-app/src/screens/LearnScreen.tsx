import React, { useState } from 'react';
import { getTableProblems } from '../data/multiplicationTables';

interface LearnScreenProps {
  onBack: () => void;
}

export const LearnScreen: React.FC<LearnScreenProps> = ({ onBack }) => {
  const [tableNum, setTableNum] = useState(1);
  const [index, setIndex] = useState(0);
  const problems = getTableProblems(tableNum);
  const current = problems[index];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="max-w-md mx-auto">
        <h1 className="text-3xl font-bold text-blue-600 mb-4 text-center">📖 تعلم الجدول</h1>
        
        <div className="flex gap-2 justify-center mb-6 flex-wrap">
          {[1, 2, 3, 4, 5].map((n) => (
            <button
              key={n}
              onClick={() => { setTableNum(n); setIndex(0); }}
              className={`w-10 h-10 rounded-lg font-bold ${tableNum === n ? 'bg-blue-600 text-white' : 'bg-white'}`}
            >
              {n}
            </button>
          ))}
        </div>

        <div className="bg-white rounded-2xl shadow-lg p-8 text-center mb-6">
          <div className="text-5xl font-bold text-blue-600">{tableNum} × {current.b}</div>
          <div className="text-5xl font-bold text-green-600">= {current.result}</div>
        </div>

        <div className="flex gap-4 mb-6">
          <button onClick={() => setIndex(Math.max(0, index - 1))} className="flex-1 bg-blue-500 text-white py-3 rounded-lg">← السابق</button>
          <button onClick={() => setIndex(Math.min(9, index + 1))} className="flex-1 bg-blue-500 text-white py-3 rounded-lg">التالي →</button>
        </div>

        <button onClick={onBack} className="w-full bg-gray-500 text-white py-3 rounded-lg">العودة</button>
      </div>
    </div>
  );
};
