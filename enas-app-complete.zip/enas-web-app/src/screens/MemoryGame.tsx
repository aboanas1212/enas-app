import React, { useState, useEffect } from 'react';
import { getRandomProblems, shuffleArray } from '../data/multiplicationTables';
import { updateStatsAfterGame } from '../data/userProgress';
import { playFeedback } from '../logic/audioManager';

interface MemoryGameProps {
  onBack: () => void;
}

export const MemoryGame: React.FC<MemoryGameProps> = ({ onBack }) => {
  const [problems] = useState(getRandomProblems(6));
  const [cards, setCards] = useState<Array<{ id: number; type: 'problem' | 'answer'; value: string; matched: boolean }>>([]);
  const [flipped, setFlipped] = useState<number[]>([]);
  const [correct, setCorrect] = useState(0);
  const [finished, setFinished] = useState(false);

  useEffect(() => {
    const newCards = problems.flatMap((p, idx) => [
      { id: idx * 2, type: 'problem' as const, value: `${p.a}×${p.b}`, matched: false },
      { id: idx * 2 + 1, type: 'answer' as const, value: `${p.result}`, matched: false },
    ]);
    setCards(shuffleArray(newCards));
  }, [problems]);

  const handleFlip = async (id: number) => {
    if (flipped.includes(id) || cards[id].matched) return;
    const newFlipped = [...flipped, id];
    setFlipped(newFlipped);

    if (newFlipped.length === 2) {
      const [id1, id2] = newFlipped;
      const card1 = cards[id1];
      const card2 = cards[id2];

      if ((card1.type === 'problem' && card2.type === 'answer') || (card1.type === 'answer' && card2.type === 'problem')) {
        const problemIdx = card1.type === 'problem' ? id1 : id2;
        const answerIdx = card1.type === 'answer' ? id1 : id2;
        
        const problemNum = parseInt(cards[problemIdx].value.split('×')[0]);
        const answerNum = parseInt(cards[answerIdx].value);
        
        if (problems.some(p => p.a === problemNum && p.result === answerNum)) {
          await playFeedback('correct');
          const newCards = [...cards];
          newCards[id1].matched = true;
          newCards[id2].matched = true;
          setCards(newCards);
          setCorrect(correct + 1);
          
          if (correct + 1 === problems.length) {
            updateStatsAfterGame({
              id: Date.now().toString(),
              gameType: 'memory',
              table: 5,
              difficulty: 'medium',
              correct: problems.length,
              incorrect: 0,
              totalTime: 0,
              date: new Date().toISOString(),
              percentage: 100,
            });
            setFinished(true);
          }
        } else {
          await playFeedback('wrong');
        }
      }
      setTimeout(() => setFlipped([]), 600);
    }
  };

  if (finished) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-indigo-50 to-purple-100 p-4 flex items-center justify-center">
        <div className="max-w-md w-full bg-white rounded-2xl shadow-2xl p-8 text-center">
          <div className="text-6xl mb-4">🧠</div>
          <h2 className="text-3xl font-bold text-gray-800 mb-4">رائع!</h2>
          <div className="text-lg text-gray-600 mb-6">لقد طابقت جميع البطاقات!</div>
          <button onClick={onBack} className="w-full bg-indigo-500 text-white py-3 rounded-lg">العودة</button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 to-purple-100 p-4">
      <div className="max-w-md mx-auto">
        <h1 className="text-3xl font-bold text-indigo-600 mb-6 text-center">🧠 لعبة الذاكرة</h1>

        <div className="grid grid-cols-3 gap-3 mb-6">
          {cards.map((card, idx) => (
            <button
              key={idx}
              onClick={() => handleFlip(idx)}
              className={`h-24 rounded-lg font-bold text-sm transition-all ${
                card.matched
                  ? 'bg-green-500 text-white'
                  : flipped.includes(idx)
                  ? 'bg-white text-gray-800'
                  : 'bg-indigo-500 text-white'
              }`}
            >
              {flipped.includes(idx) || card.matched ? card.value : '?'}
            </button>
          ))}
        </div>

        <div className="text-center text-gray-600 mb-6">
          {correct}/{problems.length} مطابقات
        </div>

        <button onClick={onBack} className="w-full bg-gray-500 text-white py-3 rounded-lg">العودة</button>
      </div>
    </div>
  );
};
