import React, { useState, useEffect } from 'react';
import { getRandomProblems } from '../data/multiplicationTables';
import { updateStatsAfterGame } from '../data/userProgress';
import { playFeedback } from '../logic/audioManager';

interface CatchGameProps {
  onBack: () => void;
}

export const CatchGame: React.FC<CatchGameProps> = ({ onBack }) => {
  const [problems] = useState(getRandomProblems(10));
  const [index, setIndex] = useState(0);
  const [correct, setCorrect] = useState(0);
  const [finished, setFinished] = useState(false);
  const [fallingPos, setFallingPos] = useState(0);
  const [caught, setCaught] = useState(false);

  const current = problems[index];

  useEffect(() => {
    if (caught) return;
    const interval = setInterval(() => {
      setFallingPos((p) => {
        if (p >= 80) {
          playFeedback('wrong');
          handleMiss();
          return 0;
        }
        return p + 5;
      });
    }, 50);
    return () => clearInterval(interval);
  }, [caught]);

  const handleCatch = async (ans: number) => {
    if (ans === current.result) {
      setCaught(true);
      setCorrect(correct + 1);
      await playFeedback('correct');
      setTimeout(() => {
        if (index === problems.length - 1) {
          updateStatsAfterGame({
            id: Date.now().toString(),
            gameType: 'catch',
            table: 5,
            difficulty: 'hard',
            correct,
            incorrect: problems.length - correct - 1,
            totalTime: 0,
            date: new Date().toISOString(),
            percentage: Math.round(((correct + 1) / problems.length) * 100),
          });
          setFinished(true);
        } else {
          setIndex(index + 1);
          setCaught(false);
          setFallingPos(0);
        }
      }, 300);
    }
  };

  const handleMiss = () => {
    setCaught(true);
    setTimeout(() => {
      if (index === problems.length - 1) {
        updateStatsAfterGame({
          id: Date.now().toString(),
          gameType: 'catch',
          table: 5,
          difficulty: 'hard',
          correct,
          incorrect: problems.length - correct,
          totalTime: 0,
          date: new Date().toISOString(),
          percentage: Math.round((correct / problems.length) * 100),
        });
        setFinished(true);
      } else {
        setIndex(index + 1);
        setCaught(false);
        setFallingPos(0);
      }
    }, 300);
  };

  if (finished) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-yellow-50 to-amber-100 p-4 flex items-center justify-center">
        <div className="max-w-md w-full bg-white rounded-2xl shadow-2xl p-8 text-center">
          <div className="text-6xl mb-4">🎮</div>
          <h2 className="text-3xl font-bold text-gray-800 mb-4">انتهت اللعبة!</h2>
          <div className="text-5xl font-bold text-yellow-600 mb-6">{correct}/{problems.length}</div>
          <button onClick={onBack} className="w-full bg-yellow-500 text-white py-3 rounded-lg">العودة</button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-yellow-50 to-amber-100 p-4">
      <div className="max-w-md mx-auto">
        <h1 className="text-3xl font-bold text-yellow-600 mb-4 text-center">🎮 اصطد الإجابة</h1>

        <div className="relative bg-white rounded-lg shadow-lg h-64 mb-6 overflow-hidden">
          <div className={`absolute left-1/2 transform -translate-x-1/2 text-5xl transition-all ${caught ? 'opacity-0' : 'opacity-100'}`} style={{ top: `${fallingPos}%` }}>
            {current.result}
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-lg p-4 mb-6 text-center">
          <p className="text-gray-600 mb-2">المسألة:</p>
          <div className="text-4xl font-bold text-yellow-600">{current.a} × {current.b}</div>
        </div>

        <div className="grid grid-cols-2 gap-3 mb-6">
          {[current.result, current.result + 5, current.result - 5, current.result + 10].filter(n => n > 0).map((ans, idx) => (
            <button
              key={idx}
              onClick={() => handleCatch(ans)}
              disabled={caught}
              className="py-4 px-3 rounded-lg font-bold text-lg bg-white shadow hover:shadow-lg transition-all"
            >
              {ans}
            </button>
          ))}
        </div>

        <div className="text-center text-gray-600">
          {index + 1}/10 | ✓ {correct}
        </div>
      </div>
    </div>
  );
};
