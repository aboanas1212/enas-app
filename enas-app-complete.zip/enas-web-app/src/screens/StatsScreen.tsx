import React from 'react';
import { getUserStats } from '../data/userProgress';

interface StatsScreenProps {
  onBack: () => void;
}

export const StatsScreen: React.FC<StatsScreenProps> = ({ onBack }) => {
  const stats = getUserStats();

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="max-w-md mx-auto">
        <h1 className="text-3xl font-bold text-blue-600 mb-6 text-center">📊 إحصائياتي</h1>

        <div className="space-y-4 mb-6">
          <div className="bg-white rounded-lg shadow-lg p-6">
            <div className="text-sm text-gray-600 mb-1">إجمالي الألعاب</div>
            <div className="text-4xl font-bold text-blue-600">{stats.totalGames}</div>
          </div>

          <div className="bg-white rounded-lg shadow-lg p-6">
            <div className="text-sm text-gray-600 mb-1">الإجابات الصحيحة</div>
            <div className="text-4xl font-bold text-green-600">{stats.totalCorrect}</div>
          </div>

          <div className="bg-white rounded-lg shadow-lg p-6">
            <div className="text-sm text-gray-600 mb-1">الإجابات الخاطئة</div>
            <div className="text-4xl font-bold text-red-600">{stats.totalIncorrect}</div>
          </div>

          <div className="bg-white rounded-lg shadow-lg p-6">
            <div className="text-sm text-gray-600 mb-1">متوسط الدقة</div>
            <div className="text-4xl font-bold text-purple-600">{Math.round(stats.averageAccuracy)}%</div>
          </div>

          <div className="bg-white rounded-lg shadow-lg p-6">
            <div className="text-sm text-gray-600 mb-1">أفضل سلسلة</div>
            <div className="text-4xl font-bold text-orange-600">{stats.bestStreak}</div>
          </div>
        </div>

        <button onClick={onBack} className="w-full bg-blue-500 text-white py-3 rounded-lg font-bold">العودة للرئيسية</button>
      </div>
    </div>
  );
};
