import React, { useState, useEffect } from 'react';
import { getRandomProblems, getWrongAnswers, shuffleArray } from '../data/multiplicationTables';
import { updateStatsAfterGame } from '../data/userProgress';
import { playFeedback } from '../logic/audioManager';

interface SpeedGameProps {
  onBack: () => void;
}

export const SpeedGame: React.FC<SpeedGameProps> = ({ onBack }) => {
  const [problems] = useState(getRandomProblems(10));
  const [index, setIndex] = useState(0);
  const [correct, setCorrect] = useState(0);
  const [timeLeft, setTimeLeft] = useState(30);
  const [gameActive, setGameActive] = useState(true);
  const [answers, setAnswers] = useState<number[]>([]);
  const [selected, setSelected] = useState<number | null>(null);
  const [finished, setFinished] = useState(false);

  const current = problems[index];

  useEffect(() => {
    if (current) {
      const wrong = getWrongAnswers(current.result, 3);
      const all = shuffleArray([current.result, ...wrong]);
      setAnswers(all);
    }
  }, [current]);

  useEffect(() => {
    if (!gameActive) return;
    const timer = setInterval(() => {
      setTimeLeft((t) => {
        if (t <= 1) {
          setGameActive(false);
          setFinished(true);
          return 0;
        }
        return t - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [gameActive]);

  const handleAnswer = async (ans: number) => {
    if (!gameActive) return;
    setSelected(ans);
    if (ans === current.result) {
      setCorrect(correct + 1);
      await playFeedback('correct');
      setTimeout(() => {
        if (index < problems.length - 1) {
          setIndex(index + 1);
          setSelected(null);
        } else {
          setGameActive(false);
          setFinished(true);
        }
      }, 300);
    } else {
      await playFeedback('wrong');
      setTimeout(() => {
        setSelected(null);
      }, 300);
    }
  };

  if (finished) {
    const answered = Math.min(index + 1, problems.length);
    const pct = answered > 0 ? Math.round((correct / answered) * 100) : 0;
    
    useEffect(() => {
      updateStatsAfterGame({
        id: Date.now().toString(),
        gameType: 'speed',
        table: 5,
        difficulty: 'hard',
        correct,
        incorrect: answered - correct,
        totalTime: 30 - timeLeft,
        date: new Date().toISOString(),
        percentage: pct,
      });
    }, []);

    return (
      <div className="min-h-screen bg-gradient-to-br from-red-50 to-orange-100 p-4 flex items-center justify-center">
        <div className="max-w-md w-full bg-white rounded-2xl shadow-2xl p-8 text-center">
          <div className="text-6xl mb-4">{pct >= 70 ? '⚡' : '💨'}</div>
          <h2 className="text-3xl font-bold text-gray-800 mb-4">انتهى الوقت!</h2>
          <div className="text-5xl font-bold text-red-600 mb-6">{correct}</div>
          <div className="text-lg text-gray-600 mb-6">من {answered} سؤال</div>
          <button onClick={onBack} className="w-full bg-red-500 text-white py-3 rounded-lg">العودة</button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 to-orange-100 p-4">
      <div className="max-w-md mx-auto">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-3xl font-bold text-red-600">⚡ سرعة</h1>
          <div className={`text-4xl font-bold ${timeLeft <= 10 ? 'text-red-600 animate-pulse' : 'text-orange-600'}`}>
            {timeLeft}s
          </div>
        </div>

        <div className="bg-white rounded-2xl shadow-lg p-8 text-center mb-6">
          <p className="text-gray-600 mb-4">الإجابة الصحيحة؟</p>
          <div className="text-5xl font-bold text-red-600">{current.a} × {current.b}</div>
        </div>

        <div className="grid grid-cols-2 gap-3 mb-6">
          {answers.map((ans) => (
            <button
              key={ans}
              onClick={() => handleAnswer(ans)}
              disabled={!gameActive}
              className={`py-4 px-3 rounded-lg font-bold text-lg transition-all ${
                selected === ans
                  ? ans === current.result
                    ? 'bg-green-500 text-white scale-110'
                    : 'bg-red-500 text-white scale-95'
                  : 'bg-white shadow hover:shadow-lg'
              }`}
            >
              {ans}
            </button>
          ))}
        </div>

        <div className="text-center text-gray-600">
          {index + 1}/{Math.min(10, problems.length)} | ✓ {correct}
        </div>
      </div>
    </div>
  );
};
