export interface MultiplicationProblem {
  a: number;
  b: number;
  result: number;
}

const tables = {
  1: Array.from({ length: 10 }, (_, i) => ({ a: 1, b: i + 1, result: 1 * (i + 1) })),
  2: Array.from({ length: 10 }, (_, i) => ({ a: 2, b: i + 1, result: 2 * (i + 1) })),
  3: Array.from({ length: 10 }, (_, i) => ({ a: 3, b: i + 1, result: 3 * (i + 1) })),
  4: Array.from({ length: 10 }, (_, i) => ({ a: 4, b: i + 1, result: 4 * (i + 1) })),
  5: Array.from({ length: 10 }, (_, i) => ({ a: 5, b: i + 1, result: 5 * (i + 1) })),
};

export const getTableProblems = (table: number): MultiplicationProblem[] => tables[table as keyof typeof tables] || [];

export const getRandomProblems = (count: number): MultiplicationProblem[] => {
  const all = Object.values(tables).flat();
  return all.sort(() => Math.random() - 0.5).slice(0, count);
};

export const getWrongAnswers = (correct: number, count: number): number[] => {
  const answers = new Set<number>();
  while (answers.size < count) {
    const offset = Math.floor(Math.random() * 20) - 10;
    const wrong = correct + offset * 5;
    if (wrong > 0 && wrong !== correct) answers.add(wrong);
  }
  return Array.from(answers);
};

export const shuffleArray = <T>(arr: T[]): T[] => {
  const result = [...arr];
  for (let i = result.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [result[i], result[j]] = [result[j], result[i]];
  }
  return result;
};
