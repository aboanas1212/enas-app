export interface GameResult {
  id: string;
  gameType: string;
  table: number;
  difficulty: string;
  correct: number;
  incorrect: number;
  totalTime: number;
  date: string;
  percentage: number;
}

export interface UserStats {
  totalGames: number;
  totalCorrect: number;
  totalIncorrect: number;
  bestStreak: number;
  currentStreak: number;
  averageAccuracy: number;
  lastPlayed: string;
  totalPlayTime: number;
}

const DEFAULT_STATS: UserStats = {
  totalGames: 0,
  totalCorrect: 0,
  totalIncorrect: 0,
  bestStreak: 0,
  currentStreak: 0,
  averageAccuracy: 0,
  lastPlayed: '',
  totalPlayTime: 0,
};

export const getUserStats = (): UserStats => {
  try {
    const stored = localStorage.getItem('enas_stats');
    return stored ? JSON.parse(stored) : DEFAULT_STATS;
  } catch {
    return DEFAULT_STATS;
  }
};

export const updateStatsAfterGame = (result: GameResult): void => {
  const stats = getUserStats();
  stats.totalGames += 1;
  stats.totalCorrect += result.correct;
  stats.totalIncorrect += result.incorrect;
  stats.totalPlayTime += result.totalTime;
  stats.lastPlayed = new Date().toISOString();
  
  if (result.incorrect === 0) {
    stats.currentStreak += result.correct;
    stats.bestStreak = Math.max(stats.bestStreak, stats.currentStreak);
  } else {
    stats.currentStreak = 0;
  }
  
  const total = stats.totalCorrect + stats.totalIncorrect;
  stats.averageAccuracy = total > 0 ? Math.round((stats.totalCorrect / total) * 100) : 0;
  
  try {
    localStorage.setItem('enas_stats', JSON.stringify(stats));
  } catch (e) {
    console.error('خطأ في حفظ البيانات:', e);
  }
};
