let isMuted = false;

export const initializeAudioSystem = (): void => {
  try {
    const saved = localStorage.getItem('enas_muted');
    if (saved) isMuted = JSON.parse(saved);
  } catch (e) {
    console.error('خطأ في تحميل إعدادات الصوت:', e);
  }
};

const playAudio = async (path: string): Promise<void> => {
  if (isMuted) return;
  try {
    const audio = new Audio(path);
    audio.volume = 0.7;
    await audio.play();
  } catch (e) {
    console.error('خطأ في تشغيل الصوت:', e);
  }
};

export const playFeedback = (type: 'correct' | 'excellent' | 'wrong'): Promise<void> => {
  const sounds: Record<string, string> = {
    correct: '/assets/sounds/correct.mp3',
    excellent: '/assets/sounds/excellent.mp3',
    wrong: '/assets/sounds/wrong.mp3',
  };
  return playAudio(sounds[type]);
};

export const playEffect = (type: 'click' | 'success' | 'fail'): Promise<void> => {
  const sounds: Record<string, string> = {
    click: '/assets/sounds/click.mp3',
    success: '/assets/sounds/success.mp3',
    fail: '/assets/sounds/fail.mp3',
  };
  return playAudio(sounds[type]);
};

export const toggleMute = (): boolean => {
  isMuted = !isMuted;
  try {
    localStorage.setItem('enas_muted', JSON.stringify(isMuted));
  } catch (e) {
    console.error('خطأ في حفظ إعدادات الصوت:', e);
  }
  return !isMuted;
};

export const getIsMuted = (): boolean => isMuted;
